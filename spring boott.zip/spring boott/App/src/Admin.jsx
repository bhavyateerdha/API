import { Link } from "react-router-dom"

function Admin()
{
    return(
        <>
        <h1>you are at admin page</h1>
        <Link to="/library">click here to visit Library</Link>
        </>
    )

}
export default Admin