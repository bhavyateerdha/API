package com.example.projectk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectkApplicationTests {

	@Test
	void contextLoads() {
	}

}
