package com.example.projectk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.projectk.model.Users;
import com.example.projectk.repository.BookRepository;
import com.example.projectk.repository.UserRepository;


@SuppressWarnings("unused")
@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class UserController 
{

    @Autowired
    UserRepository ur;

    @Autowired
    BookRepository br;
    
    @PostMapping("/register")
    String register(@RequestBody Users u)
    {
       Users result=this.ur.findByUsername(u.getUsername());
       if(result != null)
       {
          return "username already exists";
       }
       this.ur.save(u);
       return "registration successfully done";
    }

        @PostMapping("/login")
    String Login(@RequestBody Users u)
    {
       Users result=this.ur.findByUsername(u.getUsername());
       if(result != null && result.getPassword().equals(u.getPassword()))
       {
          return "Login Successfully done";
       }
 
       return "invalid username or password";
    }


}
