import { BrowserRouter, Route, Routes } from "react-router-dom"
import Home from "./Home"
import Register from "./Register"
import Login from "./Login"
import TodoList from "./TodoList";


function App()
{
  return(
    <>
    <BrowserRouter>
        <Routes>
           <Route path="/" element={<Home/>}/>
           <Route path="/reg" element={<Register/>}/>
           <Route path="/log" element={<Login/>}/>
            <Route path="/todolist" element={<TodoList />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}
export default App
