import { useState } from "react";

function TodoList() {
  const [task, setTask] = useState("");            
  const [tasks, setTasks] = useState([]);          


  const addTask = () => {
    if (task.trim() !== "") {
      setTasks([...tasks, task]);
      setTask(""); 
    }
  };
  const deleteTask = (index) => {
    const updatedTasks = tasks.filter((_, i) => i !== index);
    setTasks(updatedTasks);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>My ToDoList</h2>

      <div style={styles.inputContainer}>
        <input
          type="text"
          placeholder="Enter a task"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          style={styles.input}
        />
        <button onClick={addTask} style={styles.addButton}>Add</button>
      </div>

      <ul style={styles.list}>
        {tasks.map((item, index) => (
          <li key={index} style={styles.listItem}>
            {item}
            <button onClick={() => deleteTask(index)} style={styles.deleteButton}>
              ❌
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
const styles = {
  container: {
    width: "400px",
    margin: "50px auto",
    padding: "20px",
    borderRadius: "10px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    fontFamily: "Arial"
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px"
  },
  inputContainer: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "15px"
  },
  input: {
    flex: 1,
    padding: "10px",
    fontSize: "16px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    marginRight: "10px"
  },
  addButton: {
    padding: "10px 20px",
    backgroundColor: "teal",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  },
  list: {
    listStyleType: "none",
    padding: 0
  },
  listItem: {
    background: "#fff",
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "5px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    boxShadow: "0 0 5px rgba(0,0,0,0.05)"
  },
  deleteButton: {
    backgroundColor: "red",
    color: "white",
    border: "none",
    borderRadius: "50%",
    cursor: "pointer",
    padding: "5px 10px"
  }
};

export default TodoList;
