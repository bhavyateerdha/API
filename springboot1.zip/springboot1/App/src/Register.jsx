import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function Register() {
  const navigate = useNavigate();
  const [form, setform] = useState({
    username: "",
    email: "",
    password: ""
  });

  const changedata = (e) => {
    setform({ ...form, [e.target.name]: e.target.value });
  };

  const submitform = async (e) => {
    e.preventDefault();
    const response = await axios.post("http://localhost:4567/register", form);
    alert(response.data);
    navigate("/log")
  };

  // Inline CSS styles
  const containerStyle = {
    width: "100%",
    maxWidth: "400px",
    padding: "30px",
    border: "1px solid #ccc",
    borderRadius: "15px",
    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)",
    backgroundColor: "#f7f9fc",
    textAlign: "center",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)"
  };

  const titleStyle = {
    color: "#333",
    marginBottom: "20px",
    fontSize: "28px"
  };

  const inputStyle = {
    width: "100%",
    padding: "12px 15px",
    margin: "10px 0",
    borderRadius: "8px",
    border: "1px solid #aaa",
    fontSize: "16px"
  };

  const buttonStyle = {
    width: "100%",
    padding: "12px",
    backgroundColor: "teal",
    color: "white",
    fontSize: "18px",
    border: "none",
    borderRadius: "8px",
    marginTop: "10px",
    cursor: "pointer",
    transition: "background 0.3s ease"
  };

  return (
    <div style={containerStyle}>
      <h1 style={titleStyle}>Registration Page</h1>
      <form onSubmit={submitform}>
        <input style={inputStyle} onChange={changedata} type="text" name="username" placeholder="Create username"/>
        <input style={inputStyle} onChange={changedata} type="email" name="email" placeholder="Enter email"/>
        <input style={inputStyle} onChange={changedata} type="password" name="password" placeholder="Create password"/>
        <button style={buttonStyle} type="submit"> Register </button>
      </form>
    </div>
  );
}

export default Register;
