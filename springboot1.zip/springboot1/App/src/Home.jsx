import { Link } from "react-router-dom";

function Home() {
  return (
    <>
      <h1 style={{ textAlign: "center", color: "teal" }}>Home page...</h1>
      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <Link to="/reg" style={{ marginRight: "10px", textDecoration: "none", color: "blue" }}>
          Click here to register
        </Link>
        <br />
        <Link to="/log" style={{ textDecoration: "none", color: "green" }}>
          Login Here
        </Link>
      </div>
    </>
  );
}

export default Home;
